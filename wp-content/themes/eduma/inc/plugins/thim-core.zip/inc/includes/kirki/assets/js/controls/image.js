/**
 * Just clone from ImageControl of wp customize
 */
wp.customize.controlConstructor['kirki-image'] = wp.customize.ImageControl;